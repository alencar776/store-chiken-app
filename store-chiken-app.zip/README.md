# Store Chiken App

Sistema de delivery com integração via WhatsApp, feito para rodar no GitHub Codespaces.